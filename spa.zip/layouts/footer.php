<div class="footer">
    <p>
        <span>Developed by</span>
        <span>Muhammad Shoaib</span>
    </p>
    <p>
        <strong>
            <a href="https://wa.me/+923011840378" class="whtsapp" redirect="true">
                <span>WhatsApp: +923011840378</span>
            </a>
        </strong>
    </p>
</div>